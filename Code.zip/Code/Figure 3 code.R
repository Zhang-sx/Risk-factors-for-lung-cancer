# ============================================================
# Meta-MR 森林图 —— Category 标题行 + Factor 缩进子行（修正版）
# ============================================================
# 布局：
#   Category → 独占一行（粗体标题）
#   Factor   → 缩进显示在 Category 下方
# MA: ● 实心圆 (shape=16)    MR: △ 空心三角 (shape=2)
# Concordant → 淡钢蓝 (#5A7D8C)    Discordant → 淡陶土 (#C2866B)
# 右侧：OR (95% CI) + Evidence
# 95% CI 线无两端竖杠
# ============================================================

library(ggplot2)
library(dplyr)
library(forcats)
library(tidyr)

# ============================================================
# 41 条数据（排除 Row 17 异常 MR）
# ============================================================

Factor <- c(
  # ---- CONCORDANT (24 entries) ----
  "Waist circumference",
  "Waist circumference (LC)",
  "Smoking",
  "Smoking (LC)",
  "Cigarettes Per Day (LC)",
  "Insomnia symptoms",
  "Insomnia (LC)",
  "Fruit intake",
  "Dried fruit intake (LC)",
  "Processed meat intake",
  "Processed meat (LC)",
  "C-reactive protein (CRP)",
  "Circulating CRP (LUSC)",
  "Leukocyte telomere length",
  "Leukocyte telomere length (LC)",
  "Family history of lung cancer",
  "COPD",
  "COPD (LC)",
  "Asthma",
  "Asthma (LC)",
  "Diabetes mellitus",
  "T1DM (LUSC)",
  "Long-term statin use",
  "HMGCR-ApoB (SCLC)",
  # ---- DISCORDANT (17 entries) ----
  "BMI — overweight",
  "BMI — obesity",
  "BMI (LC)",
  "BMI (SCLC)",
  "BMI (NSCLC)",
  "Alcohol — very light drinkers",
  "Alcohol — light drinkers",
  "Alcoholic drinks (LC)",
  "Alcohol usually taken with meals (LC)",
  "Long sleep duration",
  "Sleep duration (LC)",
  "HDL-C",
  "1-arachidonoyl-GPC (20:4n6) (LC)",
  "1-palmitoyl-2-arachidonoyl-GPC (16:0/20:4) (LC)",
  "1-stearoyl-2-arachidonoyl-GPC (18:0/20:4) (LC)",
  "Plasma fibrinogen levels",
  "Interleukin-18 levels (LC)"
)

Study_Type <- c(
  "Meta","MR",
  "Meta","MR","MR",
  "Meta","MR",
  "Meta","MR",
  "Meta","MR",
  "Meta","MR",
  "Meta","MR",
  "Meta",
  "Meta","MR",
  "Meta","MR",
  "Meta","MR",
  "Meta","MR",
  "Meta","Meta",
  "MR","MR","MR",
  "Meta","Meta",
  "MR","MR",
  "Meta","MR",
  "Meta",
  "MR","MR","MR",
  "Meta","MR"
)

OR <- c(
  1.244,1.25,
  6.814,1.58,3.00,
  1.086,1.167,
  0.882,0.271,
  1.123,1.923,
  1.34,1.15,
  1.435,1.60,
  1.909,
  2.074,1.62,
  1.418,1.054,
  1.099,1.04,
  1.07,3.036,
  0.819,0.781,
  1.20,1.91,1.26,
  0.872,0.912,
  1.52,0.19,
  1.158,0.46,
  0.826,
  1.07,1.07,1.06,
  2.016,0.76
)

LCI <- c(
  1.14,1.11,
  3.491,1.33,2.72,
  1.044,1.075,
  0.832,0.15,
  1.039,1.084,
  1.099,1.01,
  1.208,1.31,
  1.585,
  1.462,1.31,
  1.13,1.014,
  1.002,1.01,
  1.027,1.376,
  0.771,0.728,
  1.20,1.57,1.07,
  0.787,0.886,
  1.11,0.09,
  1.042,0.26,
  0.731,
  1.01,1.00,1.01,
  1.567,0.64
)

UCI <- c(
  1.356,1.41,
  13.30,1.88,3.31,
  1.13,1.267,
  0.936,0.488,
  1.213,3.409,
  1.634,1.30,
  1.704,1.96,
  2.301,
  2.944,2.01,
  1.78,1.095,
  1.206,1.072,
  1.115,6.702,
  0.869,0.838,
  1.21,2.33,1.49,
  0.966,0.937,
  2.08,0.36,
  1.286,0.83,
  0.932,
  1.13,1.14,1.12,
  2.594,0.91
)

Evidence <- c(
  "III, Very Low","Probable",
  "III, Low","Probable","Robust",
  "IV, Very Low","Probable",
  "III, Low","Probable",
  "IV, Very Low","Probable",
  "IV, Very Low","Probable",
  "IV, Very Low","Probable",
  "III, Very Low",
  "IV, Very Low","Probable",
  "IV, Very Low","Probable",
  "IV, Very Low","Robust",
  "IV, Very Low","Suggestive",
  "I, Moderate","I, Moderate",
  "Suggestive","Probable","Probable",
  "IV, Very Low","III, Very Low",
  "Robust","Suggestive",
  "IV, Very Low","Suggestive",
  "IV, Very Low",
  "Probable","Probable","Probable",
  "III, Low","Probable"
)

Category <- c(
  "Waist & Hip Circumference","Waist & Hip Circumference",
  "Smoking Status & Intensity","Smoking Status & Intensity","Smoking Status & Intensity",
  "Sleep Quality & Duration","Sleep Quality & Duration",
  "Fruits & Vegetables","Fruits & Vegetables",
  "Meat, Poultry & Seafood","Meat, Poultry & Seafood",
  "Inflammatory & Immune Biomarkers","Inflammatory & Immune Biomarkers",
  "Telomere Length & Epigenetic Aging","Telomere Length & Epigenetic Aging",
  "Family History & Genetic Predisposition",
  "Non-Infectious Respiratory Diseases","Non-Infectious Respiratory Diseases",
  "Non-Infectious Respiratory Diseases","Non-Infectious Respiratory Diseases",
  "Metabolic Disorders","Metabolic Disorders",
  "Lipid-Lowering Drugs","Lipid-Lowering Drugs",
  "Body Mass Index","Body Mass Index",
  "Body Mass Index","Body Mass Index","Body Mass Index",
  "Alcohol Consumption","Alcohol Consumption",
  "Alcohol Consumption","Alcohol Consumption",
  "Sleep Quality & Duration","Sleep Quality & Duration",
  "Lipidomics & Circulating Lipids",
  "Lipidomics & Circulating Lipids","Lipidomics & Circulating Lipids","Lipidomics & Circulating Lipids",
  "Inflammatory & Immune Biomarkers","Inflammatory & Immune Biomarkers"
)

Direction <- c(
  rep("Concordant", 24),
  rep("Discordant", 17)
)

# ============================================================
# 验证
# ============================================================
n_total <- 41
stopifnot(length(Factor)     == n_total)
stopifnot(length(Study_Type) == n_total)
stopifnot(length(OR)         == n_total)
stopifnot(length(LCI)        == n_total)
stopifnot(length(UCI)        == n_total)
stopifnot(length(Evidence)   == n_total)
stopifnot(length(Category)   == n_total)
stopifnot(length(Direction)  == n_total)
message("✓ 全部向量长度 = ", n_total, "，验证通过")

# ============================================================
# ★ 构建平铺数据（手动按行插 Category 标题，确保顺序正确）
# ============================================================

raw <- data.frame(
  Factor     = Factor,
  Study_Type = Study_Type,
  OR         = OR,
  LCI        = LCI,
  UCI        = UCI,
  Evidence   = Evidence,
  Category   = Category,
  Direction  = Direction,
  orig_order = seq_len(n_total),
  stringsAsFactors = FALSE
)

# 分别处理 Concordant 和 Discordant
build_section <- function(df_section) {
  rows <- list()
  prev_cat <- ""
  for (i in seq_len(nrow(df_section))) {
    current_cat <- df_section$Category[i]
    if (current_cat != prev_cat) {
      # 插入 Category 标题行
      rows[[length(rows) + 1]] <- data.frame(
        row_type   = "header",
        label      = current_cat,
        Study_Type = NA,
        OR         = NA,
        LCI        = NA,
        UCI        = NA,
        Evidence   = NA,
        Direction  = df_section$Direction[i],
        stringsAsFactors = FALSE
      )
      prev_cat <- current_cat
    }
    # 插入 Factor 数据行
    rows[[length(rows) + 1]] <- data.frame(
      row_type   = "factor",
      label      = df_section$Factor[i],
      Study_Type = df_section$Study_Type[i],
      OR         = df_section$OR[i],
      LCI        = df_section$LCI[i],
      UCI        = df_section$UCI[i],
      Evidence   = df_section$Evidence[i],
      Direction  = df_section$Direction[i],
      stringsAsFactors = FALSE
    )
  }
  return(bind_rows(rows))
}

plot_data <- raw %>%
  group_by(Direction) %>%
  group_split() %>%
  lapply(build_section) %>%
  bind_rows()

# ★ 分配 Y 轴位置（每个 Direction 内从下往上编号）
plot_data <- plot_data %>%
  group_by(Direction) %>%
  mutate(y_pos = seq_len(n())) %>%     # 1 = 最上面, n = 最下面
  ungroup()

# ★ 反转 Y（让第一行出现在图的最上面）
plot_data$y_pos <- max(plot_data$y_pos) - plot_data$y_pos + 1

# ---- 右侧标注（仅 factor 行）----
plot_data$OR_CI_Label <- ifelse(
  plot_data$row_type == "factor",
  sprintf("%.2f (%.2f–%.2f)", plot_data$OR, plot_data$LCI, plot_data$UCI),
  ""
)
plot_data$Evidence_Label <- ifelse(
  plot_data$row_type == "factor",
  plot_data$Evidence,
  ""
)

# ---- Direction 因子 ----
plot_data$Direction <- factor(plot_data$Direction, levels = c("Concordant", "Discordant"))

# ============================================================
# 配色
# ============================================================
dir_colors <- c(
  "Concordant" = "#5A7D8C",
  "Discordant" = "#C2866B"
)

# ============================================================
# 绘图
# ============================================================
p <- ggplot(plot_data, aes(x = OR, y = y_pos)) +
  
  # ---- 参考线 ----
geom_vline(xintercept = 1, linetype = "dashed", color = "gray45", linewidth = 0.5) +
  geom_vline(xintercept = c(0.1, 0.2, 0.5, 2, 5, 10),
             linetype = "dotted", color = "gray85", linewidth = 0.25) +
  
  # ---- 95% CI 线（仅 factor 行，无两端竖杠）----
geom_errorbarh(
  data = subset(plot_data, row_type == "factor"),
  aes(xmin = LCI, xmax = UCI, color = Direction),
  height = 0, linewidth = 0.7
) +
  
  # ---- MA: 实心圆 ● ----
geom_point(
  data = subset(plot_data, row_type == "factor" & Study_Type == "Meta"),
  aes(color = Direction), shape = 16, size = 2.5
) +
  
  # ---- MR: 空心三角 △ ----
geom_point(
  data = subset(plot_data, row_type == "factor" & Study_Type == "MR"),
  aes(color = Direction), shape = 2, size = 3.0, stroke = 0.9
) +
  
  # ---- 左侧 Category 标题（粗体，x=0.018）----
geom_text(
  data = subset(plot_data, row_type == "header"),
  aes(x = 0.018, label = label),
  hjust = 0, size = 3.8, fontface = "bold", color = "gray15"
) +
  
  # ---- 左侧 Factor 子行（缩进，x=0.055）----
geom_text(
  data = subset(plot_data, row_type == "factor"),
  aes(x = 0.055, label = label),
  hjust = 0, size = 3.8, color = "black"
) +
  
  # ---- 右侧 OR (95% CI) ----
geom_text(
  aes(x = 20, label = OR_CI_Label),
  hjust = 0, size = 3.4, color = "gray25"
) +
  
  # ---- 右侧 Evidence ----
geom_text(
  aes(x = 52, label = Evidence_Label),
  hjust = 0, size = 3.4, color = "gray45"
) +
  
  # ---- 分面 ----
facet_grid(Direction ~ ., scales = "free_y", space = "free_y", switch = "y") +
  
  # ---- 配色 ----
scale_color_manual(values = dir_colors) +
  
  # ---- 对数 X 轴 ----
scale_x_log10(
  breaks = c(0.1, 0.2, 0.5, 1, 2, 5, 10, 20),
  labels = c("0.1","0.2","0.5","1","2","5","10","20"),
  limits = c(0.015, 60)
) +
  
  # ---- Y 轴用离散刻度匹配 y_pos ----
scale_y_continuous(expand = c(0.02, 0.02)) +
  
  # ---- 标签 ----
labs(
  x = "Odds Ratio (95% CI, log scale)",
  y = "",
  title = "Meta-Analysis vs. Mendelian Randomization: Lung Cancer Risk Factors",
  subtitle = "●  Meta-analysis (observational)          △  Mendelian Randomization (genetic instrument)",
  caption = paste0(
    "Meta: random-effects summary estimates (GRADE-assessed)  |  MR: inverse-variance weighted estimates\n",
    "Concordant: MA and MR agree in direction    |    Discordant: MA and MR diverge in direction\n",
    "† MR estimate for 'Illnesses of father: lung cancer (LC)' is anomalously large (OR ≈ 7.7 × 10¹¹)\n",
    "   due to near-instrument issues in IVW-MR; not plotted. See Supplementary Methods for details."
  )
) +
  
  # ---- 主题 ----
theme_bw(base_size = 10) +
  theme(
    panel.grid.major.y   = element_blank(),
    panel.grid.minor     = element_blank(),
    panel.grid.major.x   = element_line(color = "gray92", linewidth = 0.3),
    strip.background     = element_rect(fill = "gray96", color = "gray75"),
    strip.text.y.left    = element_text(angle = 0, face = "bold", size = 10),
    strip.placement      = "outside",
    legend.position      = "none",
    plot.title           = element_text(face = "bold", size = 13),
    plot.subtitle        = element_text(size = 9, color = "gray30"),
    plot.caption         = element_text(size = 7.2, color = "gray45", hjust = 0),
    axis.title.x         = element_text(size = 10, margin = margin(t = 8)),
    axis.text.x          = element_text(size = 8.5),
    axis.text.y          = element_blank(),
    axis.ticks.y         = element_blank(),
    plot.margin          = margin(12, 100, 10, 25)
  )

# ============================================================
# 保存
# ============================================================
ggsave("C:/Users/zhang/Desktop/Figure_Meta_MR_Comparison_Final.tiff",
       p, width = 18, height = 20, dpi = 600, compression = "lzw")
ggsave("C:/Users/zhang/Desktop/Figure_Meta_MR_Comparison_Final.pdf",
       p, width = 18, height = 20)

message("✓ Done! Files saved to Desktop.")
print(p)