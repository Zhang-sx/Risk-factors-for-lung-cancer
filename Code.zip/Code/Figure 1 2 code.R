# 加载包
library(readxl)
library(dplyr)
library(ggplot2)
library(tidyr)
library(stringr)
library(patchwork)

# MA代码（请修改为您的实际文件路径）

# 读取数据（请修改为您的实际文件路径）
file_path <- "C:/Users/zhang/Desktop/MA_ForestPlot跑图.xlsx"
df_raw <- read_excel(file_path, sheet = "Forest Plot Data")

# 重命名列（适配新数据结构）
df_raw <- df_raw %>%
  rename(
    Exposures = 1,
    Comparison = 2,
    Exposures_population = 3,
    N_datasets = 4,
    Cases_total = 5,
    Effect_size_CI = 6,
    Heterogeneity = 7,
    Evidence_Class = 8,
    GRADE = 9,
    es = 10,
    lci = 11,
    uci = 12
  ) %>%
  mutate(across(everything(), as.character))

# 提取 Heterogeneity 数值
df_raw <- df_raw %>%
  mutate(Heterogeneity_num = as.numeric(str_extract(Heterogeneity, "\\d+\\.?\\d*")))

# 6 个总暴露组
group_names <- c(
  "Anthropometric & Body Composition",
  "Lifestyle & Environmental Factors",
  "Dietary Intake & Nutrition",
  "Biomarkers, Omics & Lab Tests",
  "Pre-existing Conditions & Diseases",
  "Medical Interventions & Drugs"
)

# 标记分组行并填充组别
df_clean <- df_raw %>%
  mutate(is_group_title = Exposures %in% group_names) %>%
  mutate(Group = NA_character_) %>%
  {
    current_group <- NA
    for (i in seq_len(nrow(.))) {
      if (.$is_group_title[i]) current_group <- .$Exposures[i]
      .$Group[i] <- current_group
    }
    .
  } %>%
  filter(!is_group_title, !is.na(Group), Group %in% group_names) %>%
  mutate(
    es = as.numeric(es),
    lci = as.numeric(lci),
    uci = as.numeric(uci),
    Heterogeneity_num = if_else(is.na(Heterogeneity_num), NA_real_, Heterogeneity_num)
  ) %>%
  filter(!is.na(es), !is.na(lci), !is.na(uci)) %>%
  mutate(
    Effect_text = sprintf("%.3f (%.3f-%.3f)", es, lci, uci),
    I2_text = if_else(is.na(Heterogeneity_num), "", paste0(round(Heterogeneity_num, 0), "%")),
    Evidence_Class = if_else(is.na(Evidence_Class) | Evidence_Class == "", "NS", Evidence_Class),
    GRADE = if_else(is.na(GRADE) | GRADE == "", "Not applicable", GRADE)
  ) %>%
  # 组内按 es 从小到大排序
  group_by(Group) %>%
  arrange(es, .by_group = TRUE) %>%
  mutate(order = row_number()) %>%
  ungroup()

# 高级配色
group_colors <- c(
  "Anthropometric & Body Composition" = "#4C6A8C",
  "Lifestyle & Environmental Factors" = "#C19A6B",
  "Dietary Intake & Nutrition"         = "#6B8E6E",
  "Biomarkers, Omics & Lab Tests"      = "#9B7B9C",
  "Pre-existing Conditions & Diseases" = "#B85C4A",
  "Medical Interventions & Drugs"      = "#A68A56"
)

# 定义各组的 x 轴截断值（上限）
group_cutoff <- c(
  "Anthropometric & Body Composition" = 1.5,
  "Lifestyle & Environmental Factors" = 8,
  "Dietary Intake & Nutrition"         = 2,
  "Biomarkers, Omics & Lab Tests"      = 2.5,
  "Pre-existing Conditions & Diseases" = 3,
  "Medical Interventions & Drugs"      = 1.5
)

plot_group_custom <- function(data_group, group_name, group_color) {
  data_group <- data_group %>%
    arrange(order) %>%
    mutate(ypos = row_number())
  
  n_rows <- nrow(data_group)
  
  # 原始数据范围（用于计算左侧文本布局）
  x_min_orig <- min(data_group$lci, na.rm = TRUE)
  x_max_orig <- max(data_group$uci, na.rm = TRUE)
  data_span <- x_max_orig - x_min_orig
  if(data_span == 0) data_span <- 0.5
  
  # 获取该组的 x 轴截断上限
  x_cut <- group_cutoff[group_name]
  
  # 左侧文本列坐标（基于原始最小值向左扩展）
  left_expand <- data_span * 1.2
  x_exposures   <- x_min_orig - left_expand * 0.9
  x_comparison  <- x_min_orig - left_expand * 0.6
  x_population  <- x_min_orig - left_expand * 0.20
  x_datasets    <- x_min_orig - left_expand * 0.15
  x_cases       <- x_min_orig - left_expand * 0.1
  
  # 右侧文本列坐标（基于截断值向右扩展）
  right_expand <- data_span * 1.2   # 可以适当增大以确保右侧文本完全显示
  x_effect <- x_cut + data_span * 0.05
  x_i2     <- x_cut + data_span * 0.45
  x_evid   <- x_cut + data_span * 0.65
  x_grade  <- x_cut + data_span * 0.85
  
  # 确定 x 轴 limits：必须覆盖最左和最右的文本坐标
  x_lim_left <- min(x_exposures, x_min_orig) - 0.05 * data_span   # 稍微再向左扩展一点
  x_lim_right <- max(x_grade, x_cut) + 0.2 * data_span            # 向右扩展足够空间
  x_limits <- c(x_lim_left, x_lim_right)
  
  # 为每个研究准备箭头标记：如果 uci > x_cut，则需要绘制带箭头的线段
  data_group <- data_group %>%
    mutate(
      x_seg_end = ifelse(uci > x_cut, x_cut, uci),
      need_arrow = uci > x_cut
    )
  
  p <- ggplot(data_group, aes(y = ypos)) +
    # 垂直参考线 x=1
    geom_vline(xintercept = 1, linetype = "dashed", color = "gray40", alpha = 0.7) +
    # 绘制置信区间线段
    geom_segment(data = subset(data_group, need_arrow == FALSE),
                 aes(x = lci, xend = uci, y = ypos, yend = ypos),
                 color = group_color, linewidth = 0.6) +
    geom_segment(data = subset(data_group, need_arrow == TRUE),
                 aes(x = lci, xend = x_seg_end, y = ypos, yend = ypos),
                 color = group_color, linewidth = 0.6,
                 arrow = arrow(length = unit(0.15, "cm"), type = "closed")) +
    # 效应量点
    geom_point(data = data_group,
               aes(x = ifelse(es > x_cut, x_cut, es)),
               color = group_color, size = 2) +
    # 左侧文本列
    geom_text(aes(x = x_exposures, label = Exposures), hjust = 0, size = 3) +
    geom_text(aes(x = x_comparison, label = Comparison), hjust = 0, size = 3) +
    geom_text(aes(x = x_population, label = Exposures_population), hjust = 0, size = 3) +
    geom_text(aes(x = x_datasets, label = N_datasets), hjust = 0, size = 3) +
    geom_text(aes(x = x_cases, label = Cases_total), hjust = 0, size = 3) +
    # 右侧文本列
    geom_text(aes(x = x_effect, label = Effect_text), hjust = 0, size = 3) +
    geom_text(aes(x = x_i2, label = I2_text), hjust = 0, size = 3) +
    geom_text(aes(x = x_evid, label = Evidence_Class), hjust = 0, size = 3) +
    geom_text(aes(x = x_grade, label = GRADE), hjust = 0, size = 3) +
    # 坐标轴设置：使用扩大的 limits，并关闭裁剪以确保文本完全可见
    scale_x_continuous(limits = x_limits, 
                       name = "Effect size (95% CI)", 
                       expand = expansion(mult = c(0, 0))) +
    scale_y_continuous(breaks = data_group$ypos, labels = NULL, name = NULL) +
    labs(title = group_name, y = NULL) +
    theme_minimal() +
    theme(
      plot.title = element_text(size = 12, face = "bold", hjust = 0.5, margin = margin(b = 10)),
      panel.grid.major.y = element_blank(),
      panel.grid.minor.y = element_blank(),
      panel.grid.major.x = element_line(color = "grey90", linewidth = 0.3),
      axis.text.y = element_blank(),
      axis.ticks.y = element_blank(),
      # 增加边距，尤其是左右边距，防止文本被切
      plot.margin = margin(10, 40, 10, 40, "pt")
    )
  
  # 添加列标题（y 坐标在最大行号 + 0.8，避免与数据重叠）
  p <- p +
    annotate("text", x = x_exposures, y = n_rows + 0.8, 
             label = "Factor", hjust = 0, size = 3.5, fontface = "bold") +
    annotate("text", x = x_comparison, y = n_rows + 0.8, 
             label = "Comparison", hjust = 0, size = 3.5, fontface = "bold") +
    annotate("text", x = x_population, y = n_rows + 0.8, 
             label = "Population", hjust = 0, size = 3.5, fontface = "bold") +
    annotate("text", x = x_datasets, y = n_rows + 0.8, 
             label = "Datasets", hjust = 0, size = 3.5, fontface = "bold") +
    annotate("text", x = x_cases, y = n_rows + 0.8, 
             label = "Cases", hjust = 0, size = 3.5, fontface = "bold") +
    annotate("text", x = x_effect, y = n_rows + 0.8, 
             label = "Effect size (95% CI)", hjust = 0, size = 3.5, fontface = "bold") +
    annotate("text", x = x_i2, y = n_rows + 0.8, 
             label = "I² (%)", hjust = 0, size = 3.5, fontface = "bold") +
    annotate("text", x = x_evid, y = n_rows + 0.8, 
             label = "Evidence Class", hjust = 0, size = 3.5, fontface = "bold") +
    annotate("text", x = x_grade, y = n_rows + 0.8, 
             label = "GRADE", hjust = 0, size = 3.5, fontface = "bold")
  
  # 可选：在截断值位置添加一条细的垂直虚线，提示截断边界
  p <- p + geom_vline(xintercept = x_cut, linetype = "dotted", color = "red", alpha = 0.5, linewidth = 0.4)
  
  return(p)
}



# 生成每个大类的森林图
group_plots <- list()
heights <- c()
for (grp in group_names) {
  sub_data <- df_clean %>% filter(Group == grp)
  if (nrow(sub_data) > 0) {
    group_plots[[grp]] <- plot_group_custom(sub_data, grp, group_colors[grp])
    heights <- c(heights, nrow(sub_data))
  }
}

# 设定每行物理高度（cm）
per_row_height_cm <- 3
height_units <- lapply(heights, function(h) unit(h * per_row_height_cm, "cm"))

# 纵向拼接所有森林图
combined_plot <- wrap_plots(group_plots, ncol = 1, guides = "collect") +
  plot_layout(heights = height_units)

# 显示图形
print(combined_plot)

# 保存为 PDF（15×15 cm）
ggsave("Forest_Plot_Arrows.pdf", combined_plot, width = 25, height = 15, units = "cm")


# 孟德尔
# 加载包
library(readxl)
library(dplyr)
library(ggplot2)
library(tidyr)
library(stringr)
library(patchwork)

# 读取数据（请修改为您的实际文件路径）
file_path <- "C:/Users/zhang/Desktop/MR_ForestPlot_跑图.xlsx"
df_raw <- read_excel(file_path, sheet = "MR Forest Plot Data")

# 重命名列
df_raw <- df_raw %>%
  rename(
    Exposure = 1,
    No_IVs = 2,
    Outcome = 3,
    Cases = 4,
    Unit = 5,
    MR_method = 6,
    Effect_size_CI = 7,
    Evidence = 8,
    es = 9,
    lci = 10,
    uci = 11
  ) %>%
  mutate(across(everything(), as.character))

# 转换效应量数值
df_clean <- df_raw %>%
  mutate(
    es = as.numeric(es),
    lci = as.numeric(lci),
    uci = as.numeric(uci)
  )

# 分组名称
group_names <- c(
  "Anthropometric & Body Composition",
  "Lifestyle & Environmental Factors",
  "Dietary Intake & Nutrition",
  "Biomarkers, Omics & Lab Tests",
  "Pre-existing Conditions & Diseases",
  "Medical Interventions & Drugs"
)

# 标记分组标题行并填充组别
df_clean <- df_clean %>%
  mutate(is_group_title = Exposure %in% group_names) %>%
  mutate(Group = NA_character_) %>%
  {
    current_group <- NA
    for (i in seq_len(nrow(.))) {
      if (.$is_group_title[i]) current_group <- .$Exposure[i]
      .$Group[i] <- current_group
    }
    .
  } %>%
  filter(!is_group_title, !is.na(Group), Group %in% group_names) %>%
  filter(!is.na(es), !is.na(lci), !is.na(uci)) %>%
  mutate(
    Effect_text = sprintf("%.3f (%.3f-%.3f)", es, lci, uci),
    Evidence = if_else(is.na(Evidence) | Evidence == "", "Not reported", Evidence)
  ) %>%
  group_by(Group) %>%
  arrange(es, .by_group = TRUE) %>%
  mutate(order = row_number()) %>%
  ungroup()

# 配色
group_colors <- c(
  "Anthropometric & Body Composition" = "#4C6A8C",
  "Lifestyle & Environmental Factors" = "#C19A6B",
  "Dietary Intake & Nutrition"         = "#6B8E6E",
  "Biomarkers, Omics & Lab Tests"      = "#9B7B9C",
  "Pre-existing Conditions & Diseases" = "#B85C4A",
  "Medical Interventions & Drugs"      = "#A68A56"
)

# 各组截断值上限（Medical Interventions 单独处理）
group_cutoff <- c(
  "Anthropometric & Body Composition" = 2.5,
  "Lifestyle & Environmental Factors" = 3.5,
  "Dietary Intake & Nutrition"         = 2.0,
  "Biomarkers, Omics & Lab Tests"      = 5.0,
  "Pre-existing Conditions & Diseases" = 3.0,
  "Medical Interventions & Drugs"      = NA
)

# 绘图函数
plot_group_custom <- function(data_group, group_name, group_color) {
  data_group <- data_group %>%
    arrange(order) %>%
    mutate(ypos = row_number())
  
  n_rows <- nrow(data_group)
  
  # 特殊处理 Medical Interventions & Drugs 组
  if (group_name == "Medical Interventions & Drugs") {
    # 固定 x 轴显示范围
    x_lim_low <- 0.9
    x_lim_high <- 1.0
    
    # 获取原始效应量范围，用于左侧文本布局
    x_min_orig <- min(data_group$lci, na.rm = TRUE)
    x_max_orig <- max(data_group$uci, na.rm = TRUE)
    data_span <- max(0.1, x_max_orig - x_min_orig)
    left_expand <- data_span * 1.5
    
    # 左侧文本 x 坐标
    x_Exposure <- x_lim_low - left_expand * 0.9
    x_Outcome  <- x_lim_low - left_expand * 0.7
    x_Cases    <- x_lim_low - left_expand * 0.5
    x_Unit     <- x_lim_low - left_expand * 0.35
    x_MRmethod <- x_lim_low - left_expand * 0.2
    
    # 右侧文本 x 坐标（确保在 x_lim_high 右侧足够远）
    x_EffectText <- x_lim_high + data_span * 0.1
    x_Evidence   <- x_lim_high + data_span * 0.35
    
    # x 轴 limits：左侧扩展到能覆盖所有左侧文本，右侧扩展到能覆盖所有右侧文本
    x_lim_left_total <- min(x_Exposure, x_lim_low) - 0.05 * data_span
    x_lim_right_total <- max(x_Evidence, x_lim_high) + 0.2 * data_span
    x_limits <- c(x_lim_left_total, x_lim_right_total)
    
    p <- ggplot(data_group, aes(y = ypos)) +
      geom_vline(xintercept = 1, linetype = "dashed", color = "gray40", alpha = 0.7) +
      geom_segment(aes(x = lci, xend = uci, y = ypos, yend = ypos),
                   color = group_color, linewidth = 0.6) +
      geom_point(aes(x = es), color = group_color, size = 2) +
      # 左侧文本
      geom_text(aes(x = x_Exposure, label = Exposure), hjust = 0, size = 3) +
      geom_text(aes(x = x_Outcome, label = Outcome), hjust = 0, size = 3) +
      geom_text(aes(x = x_Cases, label = Cases), hjust = 0, size = 3) +
      geom_text(aes(x = x_Unit, label = Unit), hjust = 0, size = 3) +
      geom_text(aes(x = x_MRmethod, label = MR_method), hjust = 0, size = 3) +
      # 右侧文本
      geom_text(aes(x = x_EffectText, label = Effect_text), hjust = 0, size = 3) +
      geom_text(aes(x = x_Evidence, label = Evidence), hjust = 0, size = 3) +
      scale_x_continuous(limits = x_limits, name = "Effect size (95% CI)", expand = expansion(mult = c(0, 0))) +
      scale_y_continuous(breaks = data_group$ypos, labels = NULL, name = NULL,
                         expand = expansion(mult = c(0.1, 0.2))) +  # 上下留空，防止被切
      labs(title = group_name, y = NULL) +
      theme_minimal() +
      theme(
        plot.title = element_text(size = 12, face = "bold", hjust = 0.5, margin = margin(b = 10)),
        panel.grid.major.y = element_blank(),
        panel.grid.minor.y = element_blank(),
        panel.grid.major.x = element_line(color = "grey90", linewidth = 0.3),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        plot.margin = margin(15, 40, 20, 40, "pt")  # 增加下边距 (bottom=20)
      )
    
    # 添加列标题（y 坐标比最大行号稍高）
    p <- p +
      annotate("text", x = x_Exposure, y = n_rows + 0.8, label = "Exposure", hjust = 0, size = 3.5, fontface = "bold") +
      annotate("text", x = x_Outcome, y = n_rows + 0.8, label = "Outcome", hjust = 0, size = 3.5, fontface = "bold") +
      annotate("text", x = x_Cases, y = n_rows + 0.8, label = "Cases", hjust = 0, size = 3.5, fontface = "bold") +
      annotate("text", x = x_Unit, y = n_rows + 0.8, label = "Unit", hjust = 0, size = 3.5, fontface = "bold") +
      annotate("text", x = x_MRmethod, y = n_rows + 0.8, label = "MR method", hjust = 0, size = 3.5, fontface = "bold") +
      annotate("text", x = x_EffectText, y = n_rows + 0.8, label = "Effect size (95% CI)", hjust = 0, size = 3.5, fontface = "bold") +
      annotate("text", x = x_Evidence, y = n_rows + 0.8, label = "Evidence", hjust = 0, size = 3.5, fontface = "bold")
    
    return(p)
  }
  
  # 其他组（截断+箭头）
  x_cut <- group_cutoff[group_name]
  if (is.na(x_cut)) x_cut <- max(data_group$uci, na.rm = TRUE)
  
  x_min_orig <- min(data_group$lci, na.rm = TRUE)
  x_max_orig <- max(data_group$uci, na.rm = TRUE)
  data_span <- x_max_orig - x_min_orig
  if (data_span == 0) data_span <- 0.5
  
  left_expand <- data_span * 1.2
  x_Exposure <- x_min_orig - left_expand * 0.9
  x_Outcome  <- x_min_orig - left_expand * 0.7
  x_Cases    <- x_min_orig - left_expand * 0.5
  x_Unit     <- x_min_orig - left_expand * 0.35
  x_MRmethod <- x_min_orig - left_expand * 0.2
  
  x_EffectText <- x_cut + data_span * 0.05
  x_Evidence   <- x_cut + data_span * 0.30
  
  x_lim_left <- min(x_Exposure, x_min_orig) - 0.05 * data_span
  x_lim_right <- max(x_Evidence, x_cut) + 0.2 * data_span
  x_limits <- c(x_lim_left, x_lim_right)
  
  data_group <- data_group %>%
    mutate(
      x_seg_end = ifelse(uci > x_cut, x_cut, uci),
      need_arrow = uci > x_cut
    )
  
  p <- ggplot(data_group, aes(y = ypos)) +
    geom_vline(xintercept = 1, linetype = "dashed", color = "gray40", alpha = 0.7) +
    geom_segment(data = subset(data_group, need_arrow == FALSE),
                 aes(x = lci, xend = uci, y = ypos, yend = ypos),
                 color = group_color, linewidth = 0.6) +
    geom_segment(data = subset(data_group, need_arrow == TRUE),
                 aes(x = lci, xend = x_seg_end, y = ypos, yend = ypos),
                 color = group_color, linewidth = 0.6,
                 arrow = arrow(length = unit(0.15, "cm"), type = "closed")) +
    geom_point(data = data_group,
               aes(x = ifelse(es > x_cut, x_cut, es)),
               color = group_color, size = 2) +
    geom_text(aes(x = x_Exposure, label = Exposure), hjust = 0, size = 3) +
    geom_text(aes(x = x_Outcome, label = Outcome), hjust = 0, size = 3) +
    geom_text(aes(x = x_Cases, label = Cases), hjust = 0, size = 3) +
    geom_text(aes(x = x_Unit, label = Unit), hjust = 0, size = 3) +
    geom_text(aes(x = x_MRmethod, label = MR_method), hjust = 0, size = 3) +
    geom_text(aes(x = x_EffectText, label = Effect_text), hjust = 0, size = 3) +
    geom_text(aes(x = x_Evidence, label = Evidence), hjust = 0, size = 3) +
    scale_x_continuous(limits = x_limits, name = "Effect size (95% CI)", expand = expansion(mult = c(0, 0))) +
    scale_y_continuous(breaks = data_group$ypos, labels = NULL, name = NULL,
                       expand = expansion(mult = c(0.05, 0.1))) +
    labs(title = group_name, y = NULL) +
    theme_minimal() +
    theme(
      plot.title = element_text(size = 12, face = "bold", hjust = 0.5, margin = margin(b = 10)),
      panel.grid.major.y = element_blank(),
      panel.grid.minor.y = element_blank(),
      panel.grid.major.x = element_line(color = "grey90", linewidth = 0.3),
      axis.text.y = element_blank(),
      axis.ticks.y = element_blank(),
      plot.margin = margin(10, 40, 10, 40, "pt")
    )
  
  p <- p +
    annotate("text", x = x_Exposure, y = n_rows + 0.8, label = "Exposure", hjust = 0, size = 3.5, fontface = "bold") +
    annotate("text", x = x_Outcome, y = n_rows + 0.8, label = "Outcome", hjust = 0, size = 3.5, fontface = "bold") +
    annotate("text", x = x_Cases, y = n_rows + 0.8, label = "Cases", hjust = 0, size = 3.5, fontface = "bold") +
    annotate("text", x = x_Unit, y = n_rows + 0.8, label = "Unit", hjust = 0, size = 3.5, fontface = "bold") +
    annotate("text", x = x_MRmethod, y = n_rows + 0.8, label = "MR method", hjust = 0, size = 3.5, fontface = "bold") +
    annotate("text", x = x_EffectText, y = n_rows + 0.8, label = "Effect size (95% CI)", hjust = 0, size = 3.5, fontface = "bold") +
    annotate("text", x = x_Evidence, y = n_rows + 0.8, label = "Evidence", hjust = 0, size = 3.5, fontface = "bold")
  
  p <- p + geom_vline(xintercept = x_cut, linetype = "dotted", color = "red", alpha = 0.5, linewidth = 0.4)
  
  return(p)
}

# 生成所有组的图
group_plots <- list()
heights <- c()
for (grp in group_names) {
  sub_data <- df_clean %>% filter(Group == grp)
  if (nrow(sub_data) > 0) {
    group_plots[[grp]] <- plot_group_custom(sub_data, grp, group_colors[grp])
    heights <- c(heights, nrow(sub_data))
  }
}

# 每行高度（cm），对于单行的 Medical 组稍微增加一点
per_row_height_cm <- 3.5   # 从 3 增加到 3.5，确保单行有足够高度
height_units <- lapply(heights, function(h) unit(h * per_row_height_cm, "cm"))

combined_plot <- wrap_plots(group_plots, ncol = 1, guides = "collect") +
  plot_layout(heights = height_units)

# 显示
print(combined_plot)

# 保存 PDF，同时增加底部边距
total_height <- sum(heights) * per_row_height_cm
ggsave("MR_ForestPlot_Fixed.pdf", combined_plot, width = 35, height = total_height + 1, units = "cm", limitsize = FALSE)